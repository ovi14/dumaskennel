<?php
// login credentials
define ('LOGIN_USERNAME','a');	// duma
define ('LOGIN_PASSWORD','a');	// Duma_Admin_123+

define ('ADMIN_URL','localhost/dumaskennel');	// www.dumaskennel.com/administrare

?>
