<?php

$database_server = "localhost";
$database_user = "root";
$database_password = "";
$database = "dumaskennel";

?>