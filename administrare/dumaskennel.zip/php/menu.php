<?php
require_once(dirname(__FILE__).'/../const_config.php');
?>
<div align="center" id="div_menu">
	<a href="http://<?=ADMIN_URL?>/?mops" class="menu-button">MOPS</a>
	<a href="http://<?=ADMIN_URL?>/?pui" class="menu-button">PUI</a>
	<a href="http://<?=ADMIN_URL?>/?monta" class="menu-button">MONTA</a>
</div>