<?php

$database_server = "localhost";
$database_user = "root";	// dumasken_admin
$database_password = "";	// 6eamsvhe2ba
$database = "dumaskennel";	// dumasken_dumaskennel

?>